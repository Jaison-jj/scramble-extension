export const COOKIE_URL = 'https://portal.demo.scrambleid.com';
export const COOKIE_NAME = 'scramble-session-dem'
export const INJECTION_PAGE_URL = 'https://demoguest.com/demo/vdi'
export const CRED_BASE_URL = 'https://demo.scrambleid.com'